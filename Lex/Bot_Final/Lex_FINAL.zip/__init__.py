# Importando os intents
from saudacoes import saudacoes_intent
from rekognition import detectar_locais_proliferacao
from bedrock import obter_dicas_dengue_bedrock
from denunciaFoto import denunciaFoto_intent

from lambda_function import lambda_handler
